from flask import Flask, request, jsonify, render_template
from hospital_module import Hospital

app = Flask(__name__)
hospital = Hospital()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_patient', methods=['POST'])
def add_patient():
    data = request.get_json()
    try:
        hospital.pq.enqueue(
            data['name'],
            int(data['id']),
            int(data['age']),
            data['gender'],
            data['condition'],
            int(data['severity']),
            int(data['condition_id'])
        )
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get_queue', methods=['GET'])
def get_queue():
    queue = hospital.pq.display()
    return jsonify({'queue': queue})

@app.route('/serve_patient', methods=['POST'])
def serve_patient():
    patient = hospital.pq.dequeue()
    if not patient:
        return jsonify({'served': None})
    doctor = hospital.assign_doctor(patient)
    return jsonify({
        'served': {
            'patient': str(patient),
            'doctor': str(doctor)
        }
    })

if __name__ == '__main__':
    app.run(debug=True)
