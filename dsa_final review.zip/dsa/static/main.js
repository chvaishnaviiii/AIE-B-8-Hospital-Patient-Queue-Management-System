// Add Patient (no auto-refresh)
document.getElementById('patientForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());

  const res = await fetch('/add_patient', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  const result = await res.json();
  if (result.success) {
    alert('Patient added successfully!');
    e.target.reset();
  } else {
    alert('Error: ' + result.error);
  }
});

// Show Queue
document.getElementById('refreshQueue').addEventListener('click', async () => {
  const res = await fetch('/get_queue');
  const { queue } = await res.json();
  const list = document.getElementById('queueList');
  list.innerHTML = '';
  if (queue.length === 0) {
    list.innerHTML = '<li class="list-group-item text-muted">No patients in queue</li>';
  } else {
    queue.forEach(item => {
      const li = document.createElement('li');
      li.className = 'list-group-item';
      li.textContent = item;
      list.appendChild(li);
    });
  }
});

// Treat Next Patient
document.getElementById('treatPatient').addEventListener('click', async () => {
  const res = await fetch('/serve_patient', { method: 'POST' });
  const data = await res.json();
  const info = document.getElementById('servedInfo');
  if (data.served) {
    info.textContent = `✅ Treated: ${data.served.patient} | Doctor: ${data.served.doctor}`;
  } else {
    info.textContent = 'No patients to treat.';
  }
});
