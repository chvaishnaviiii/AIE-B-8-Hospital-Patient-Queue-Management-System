class Patient:
    def __init__(self, name, id, age, gender, condition, severity, condition_id):
        self.details = {
            "name": name,
            "id": id,
            "age": age,
            "gender": gender,
            "condition": condition,
            "severity": severity,
            "condition_id": condition_id
        }

    def __str__(self):
        return (f"Name: {self.details['name']}, Age: {self.details['age']}, "
                f"Gender: {self.details['gender']}, Condition: {self.details['condition']}, "
                f"Severity: {self.details['severity']}")


class Doctor:
    def __init__(self, name, specialization):
        self.details = {
            "name": name,
            "specialization": specialization
        }

    def __str__(self):
        return f"Dr. {self.details['name']} (Specialization: {self.details['specialization']})"


class Node:
    def __init__(self, patient):
        self.patient = patient
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, name, id, age, gender, condition, severity, condition_id):
        new_patient = Patient(name, id, age, gender, condition, severity, condition_id)
        new_node = Node(new_patient)
        if self.head is None or self.head.patient.details["severity"] > severity:
            new_node.next = self.head
            self.head = new_node
        else:
            temp = self.head
            while temp.next and temp.next.patient.details["severity"] <= severity:
                temp = temp.next
            new_node.next = temp.next
            temp.next = new_node

    def delete(self):
        if self.head is None:
            return None
        patient = self.head.patient
        self.head = self.head.next
        return patient

    def display(self):
        result = []
        temp = self.head
        while temp:
            result.append(str(temp.patient))
            temp = temp.next
        return result


class PriorityQueue:
    def __init__(self):
        self.queue = LinkedList()

    def enqueue(self, name, id, age, gender, condition, severity, condition_id):
        self.queue.insert(name, id, age, gender, condition, severity, condition_id)

    def dequeue(self):
        return self.queue.delete()

    def display(self):
        return self.queue.display()


class Hospital:
    def __init__(self):
        self.pq = PriorityQueue()
        self.doctors = {
            1: Doctor("Smith", "Cardiology"),
            2: Doctor("Johnson", "Neurology"),
            3: Doctor("Brown", "Orthopedics"),
            4: Doctor("Taylor", "General Medicine")
        }

    def assign_doctor(self, patient):
        return self.doctors.get(patient.details["condition_id"])
